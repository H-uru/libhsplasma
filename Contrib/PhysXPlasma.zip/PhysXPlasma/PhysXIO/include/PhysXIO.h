#ifndef PHYSXIO_H
#define PHYSXIO_H

class PhysXIO
{
private:
	
	PhysXIO()
	{
	}

public:

	static bool readTriangleMesh(unsigned char * data, unsigned int size, float *& vertices, unsigned int &numVertices, unsigned int *& indices, unsigned int &numIndices);

	static bool readConvexMesh(unsigned char * data, unsigned int size, float *& vertices, unsigned int &numVertices, unsigned int *& indices, unsigned int &numIndices);

	static bool writeTriangleMesh(float * verts, unsigned int numVerts, unsigned int * indices, unsigned int numIndices, unsigned char *& buffer, unsigned int & bufSize);

	static bool writeConvexMesh(float * verts, unsigned int numVerts, unsigned int * indices, unsigned int numIndices, unsigned char *& buffer, unsigned int & bufSize);

	static void release();
};


#endif